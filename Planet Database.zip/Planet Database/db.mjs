import pgPromise from "pg-promise";

const pgp = pgPromise();
const db = pgp("postgres://postgres:mappamondo@localhost:5432/postgres");

const setupDb = async () => {
  try {
    await db.none(`DROP TABLE IF EXISTS planets;`);
    await db.none(`
      CREATE TABLE planets(
        id SERIAL NOT NULL PRIMARY KEY,
        name TEXT NOT NULL,
        image TEXT
      );
    `);
    await db.none(`DROP TABLE IF EXISTS users;`);
    await db.none(`
      CREATE TABLE users(
        id SERIAL NOT NULL PRIMARY KEY,
        username TEXT NOT NULL,
        password TEXT,
        token TEXT
      );
    `);
    await db.none(`INSERT INTO planets (name) VALUES ('Earth');`);
    await db.none(`INSERT INTO planets (name) VALUES ('Mars');`);
    
    await db.none(`INSERT INTO users (username, password) VALUES ('Dummy', 'Dummy');`);

    console.log('Database setup completed.');
  } catch (error) {
    console.error('Error setting up the database:', error);
  }
};

setupDb();

export { db };

