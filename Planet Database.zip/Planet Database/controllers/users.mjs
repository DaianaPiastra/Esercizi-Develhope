import { db } from "../db.mjs";
import jwt from "jsonwebtoken";
import * as dotenv from "dotenv";
dotenv.config();

const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await db.one(`SELECT * FROM users WHERE username=$1`, [
      username,
    ]);

    if (user && user.password === password) {
      const payload = {
        id: user.id,
        username,
      };
      const { SECRET = "" } = process.env;
      const token = jwt.sign(payload, SECRET);
      await db.none(`UPDATE users SET token=$2 WHERE id=$1`, [user.id, token]);
      res.status(200).json({ id: user.id, username, token });
    } else {
      res.status(400).json({ msg: "Username or password incorrect" });
    }
  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({ msg: "Internal server error" });
  }
};

const signup = async (req, res) => {
  const { username, password } = req.body;

  const user = await db.oneOrNone(
    `SELECT * FROM users WHERE username=$1`,
    username
  );

  if (user) {
    res.status(400).json({ message: "User already exists." });
  } else {
    const { id } = await db.one(
      `INSERT INTO users (username, password) VALUES ($1, $2) RETURNING id`,
      [username, password]
    );
    res.status(201).json({ id, message: "User created successfully!" });

    res.status(500).json({ message: "Error creating user", error: err });
  }
};

const logout = async (req, res) => {
    try {
      await db.none(`UPDATE users SET token=null WHERE id=$1`, [user?.id, null]);
      res.status(200).json({ message: "Logged out successfully." });
    } catch (err) {
      res.status(500).json({ message: "Error logging out", error: err });
    }
  };

export { login, signup , logout};
